<?php
/* Database connection information */
	$gaSql['user']       = "root";
	$gaSql['password']   = "Vz6toYT1Qb";
	$gaSql['db']         = "rova";
	$gaSql['server']     = "localhost";
	
?>